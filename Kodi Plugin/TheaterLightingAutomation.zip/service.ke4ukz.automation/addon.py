# Copyright 2015 Jonathan Dean (ke4ukz@gmx.com)
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
#

import serial
import xbmc
import xbmcaddon

ADDON_ID = 'service.ke4ukz.automation'
settings = xbmcaddon.Addon(id=ADDON_ID)

class AutomationHandler(xbmc.Player):

	def __init__ (self):
		xbmc.Player.__init__(self)

	def sendCommand(self,command):
		try:
			self.serialPort.write(command + "\n")
		except Exception as e:
			xbmc.log('Error writing to serial port: ' + str(e) )

	def Run(self):
		while(not xbmc.abortRequested):
			xbmc.sleep(1000)

	def StartUp(self):
		xbmc.log('Starting ' + ADDON_ID)
		try:
			self.serialPort = serial.Serial()
			self.serialPort.setPort(settings.getSetting("serialport") )
			self.serialPort.setBaudrate(int(settings.getSetting("baudrate") ) )
			self.serialPort.setByteSize(8)
			self.serialPort.setParity('N')
			self.serialPort.setStopbits(1)
			self.serialPort.open()
			xbmc.sleep(2000)
			self.sendCommand("on")
		except Exception as e:
			xbmc.log("Error opening serial port: " + str(e) )
			return False
		else:
			return True

	def ShutDown(self):
		xbmc.log('Shutting down ' + ADDON_ID)
		try:
			self.sendCommand("off")
			self.serialPort.close()
		except Exception as e:
			xbmc.log("Error closing serial port: " + str(e) )

	def onPlayBackStarted(self):
		self.sendCommand("play")

	def onPlayBackEnded(self):
		self.sendCommand("stop")

	def onPlayBackStopped(self):
		self.sendCommand("stop")

	def onPlayBackPaused(self):
		if (settings.getSetting("ignorepause") == "false"):
			self.sendCommand("pause")

	def onPlayBackResumed(self):
		if (settings.getSetting("ignorepause") == "false"):
			self.sendCommand("resume")

# -- Main Code ----------------------------------------------
handler=AutomationHandler()
if (handler.StartUp() ):
	handler.Run()
	handler.ShutDown()
